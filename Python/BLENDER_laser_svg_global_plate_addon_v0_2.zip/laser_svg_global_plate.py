bl_info = {
    "name": "Laser SVG Exporter (Global-Axis Plates)",
    "author": "OpenAI",
    "version": (0, 2, 0),
    "blender": (4, 2, 0),
    "location": "File > Export > Laser SVG (.svg)",
    "description": "Export the Top/Front/Right face of thick global-axis-aligned plate meshes as 1:1 SVG outlines",
    "category": "Import-Export",
}

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ExportHelper
from mathutils import Vector
from collections import defaultdict
import math
import html


AXIS_NAMES = {0: "X", 1: "Y", 2: "Z"}
PLANE_FROM_AXIS = {0: "YZ", 1: "XZ", 2: "XY"}
# Blender orthographic view convention for the visible plate face:
#   YZ plate -> RIGHT view  -> +X side
#   XZ plate -> FRONT view  -> -Y side
#   XY plate -> TOP view    -> +Z side
VIEW_SIGN_FROM_AXIS = {0: +1, 1: -1, 2: +1}
VIEW_NAME_FROM_AXIS = {0: "Right", 1: "Front", 2: "Top"}


def _world_vertices(obj_eval, mesh):
    mw = obj_eval.matrix_world
    return [mw @ v.co for v in mesh.vertices]


def _world_normal(obj_eval, poly):
    # Correct normal transform for non-uniform object scaling.
    normal_matrix = obj_eval.matrix_world.to_3x3().inverted().transposed()
    n = normal_matrix @ poly.normal
    if n.length_squared:
        n.normalize()
    return n


def _project(v, thin_axis):
    # Projection is always onto a GLOBAL coordinate plane.
    if thin_axis == 2:      # XY plate; thickness in Z
        return (v.x, v.y)
    if thin_axis == 1:      # XZ plate; thickness in Y
        return (v.x, v.z)
    return (v.y, v.z)       # YZ plate; thickness in X


def _signed_area(loop2d):
    a = 0.0
    n = len(loop2d)
    for i in range(n):
        x1, y1 = loop2d[i]
        x2, y2 = loop2d[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return 0.5 * a


def _remove_duplicate_and_collinear(points, eps=1e-12):
    if len(points) < 3:
        return points

    # Remove consecutive duplicates.
    dedup = []
    for p in points:
        if not dedup or (abs(p[0] - dedup[-1][0]) > eps or abs(p[1] - dedup[-1][1]) > eps):
            dedup.append(p)
    if len(dedup) > 1 and abs(dedup[0][0] - dedup[-1][0]) <= eps and abs(dedup[0][1] - dedup[-1][1]) <= eps:
        dedup.pop()

    if len(dedup) < 3:
        return dedup

    changed = True
    pts = dedup
    while changed and len(pts) >= 3:
        changed = False
        keep = []
        n = len(pts)
        for i in range(n):
            p0 = pts[(i - 1) % n]
            p1 = pts[i]
            p2 = pts[(i + 1) % n]
            ax, ay = p1[0] - p0[0], p1[1] - p0[1]
            bx, by = p2[0] - p1[0], p2[1] - p1[1]
            cross = ax * by - ay * bx
            scale = max(1.0, math.hypot(ax, ay), math.hypot(bx, by))
            # Remove only essentially exactly collinear points.
            if abs(cross) <= eps * scale:
                changed = True
            else:
                keep.append(p1)
        if len(keep) == len(pts) or len(keep) < 3:
            break
        pts = keep
    return pts


def _trace_loops(boundary_edges):
    """Convert an undirected degree-2 boundary edge set to closed vertex-index loops."""
    adjacency = defaultdict(list)
    for a, b in boundary_edges:
        adjacency[a].append(b)
        adjacency[b].append(a)

    bad = {v: nbrs for v, nbrs in adjacency.items() if len(nbrs) != 2}
    if bad:
        sample = ", ".join(f"v{v}:degree{len(n)}" for v, n in list(bad.items())[:8])
        raise ValueError(
            "Cap boundary is not a set of simple closed loops. "
            f"Problem vertices: {sample}. The mesh may be non-manifold or the chosen cap is not planar."
        )

    unused = {tuple(sorted((a, b))) for a, b in boundary_edges}
    loops = []

    while unused:
        first_edge = next(iter(unused))
        start, nxt = first_edge
        loop = [start]
        prev, cur = start, nxt
        unused.discard(tuple(sorted((prev, cur))))

        guard = 0
        while cur != start:
            loop.append(cur)
            nbrs = adjacency[cur]
            candidate = nbrs[0] if nbrs[0] != prev else nbrs[1]
            edge = tuple(sorted((cur, candidate)))
            if edge not in unused and candidate != start:
                raise ValueError("Boundary loop tracing encountered an already-used edge; mesh boundary is ambiguous.")
            unused.discard(edge)
            prev, cur = cur, candidate
            guard += 1
            if guard > len(adjacency) + 5:
                raise ValueError("Boundary loop tracing did not close; mesh boundary appears malformed.")

        if len(loop) >= 3:
            loops.append(loop)

    return loops


def _cap_boundary_loops(obj, depsgraph, requested_plane, normal_threshold, cap_tolerance_rel, apply_modifiers):
    obj_eval = obj.evaluated_get(depsgraph) if apply_modifiers else obj
    mesh = obj_eval.to_mesh() if apply_modifiers else obj.data

    try:
        if not mesh.polygons:
            raise ValueError(f"{obj.name}: mesh contains no faces.")

        wverts = _world_vertices(obj_eval, mesh)
        mins = [min(v[i] for v in wverts) for i in range(3)]
        maxs = [max(v[i] for v in wverts) for i in range(3)]
        ext = [maxs[i] - mins[i] for i in range(3)]

        if requested_plane == 'AUTO':
            thin_axis = min(range(3), key=lambda i: ext[i])
        elif requested_plane == 'XY':
            thin_axis = 2
        elif requested_plane == 'XZ':
            thin_axis = 1
        else:  # YZ
            thin_axis = 0

        other_ext = [ext[i] for i in range(3) if i != thin_axis]
        if min(other_ext) <= 0:
            raise ValueError(f"{obj.name}: degenerate projected size.")

        # A plate should be much thinner in one axis, but do not hard-fail: explicit plane selection
        # may be intentional. Auto mode warns by error only if clearly not plate-like.
        if requested_plane == 'AUTO' and ext[thin_axis] > 0.5 * min(other_ext):
            raise ValueError(
                f"{obj.name}: no clear thin global axis detected. Extents are "
                f"X={ext[0]:.6g}, Y={ext[1]:.6g}, Z={ext[2]:.6g}. "
                "Choose XY/XZ/YZ explicitly if this is intentional."
            )

        cap_faces = []
        for p in mesh.polygons:
            n = _world_normal(obj_eval, p)
            if abs(n[thin_axis]) >= normal_threshold:
                c = sum(wverts[vi][thin_axis] for vi in p.vertices) / len(p.vertices)
                cap_faces.append((p, c))

        if not cap_faces:
            raise ValueError(
                f"{obj.name}: no face is sufficiently parallel to global {PLANE_FROM_AXIS[thin_axis]} "
                f"(normal threshold {normal_threshold:.3f})."
            )

        max_c = max(c for _, c in cap_faces)
        min_c = min(c for _, c in cap_faces)
        thickness = max(ext[thin_axis], 1e-12)
        tol = max(thickness * cap_tolerance_rel, 1e-9)

        # Export ONLY the face seen from Blender's standard orthographic view:
        #   XY plate -> Top view   -> maximum Z
        #   XZ plate -> Front view -> minimum Y
        #   YZ plate -> Right view -> maximum X
        #
        # This matters when front/back outlines differ slightly (for example because
        # through-cut walls are tapered). We choose the cap by POSITION rather than
        # polygon-normal sign, so imported STL meshes with flipped normals still work.
        view_sign = VIEW_SIGN_FROM_AXIS[thin_axis]
        target_c = max_c if view_sign > 0 else min_c
        chosen = [p for p, c in cap_faces if abs(c - target_c) <= tol]

        edge_count = defaultdict(int)
        for p in chosen:
            ids = list(p.vertices)
            for i, a in enumerate(ids):
                b = ids[(i + 1) % len(ids)]
                edge_count[tuple(sorted((a, b)))] += 1

        boundary_edges = [e for e, count in edge_count.items() if count == 1]
        if not boundary_edges:
            raise ValueError(
                f"{obj.name}: the detected outer cap has no boundary edges. "
                "This usually means the cap selection is not the intended flat plate surface."
            )

        loops_idx = _trace_loops(boundary_edges)
        loops = []
        for loop in loops_idx:
            pts = [_project(wverts[i], thin_axis) for i in loop]
            pts = _remove_duplicate_and_collinear(pts)
            if len(pts) >= 3 and abs(_signed_area(pts)) > 1e-18:
                loops.append(pts)

        if not loops:
            raise ValueError(f"{obj.name}: no non-degenerate closed outline loops were found.")

        return loops, thin_axis, ext
    finally:
        if apply_modifiers:
            obj_eval.to_mesh_clear()


def _fmt(x):
    # Enough precision for sub-micron coordinates in normal laser-cut projects, without noisy SVGs.
    s = f"{x:.9f}".rstrip('0').rstrip('.')
    return s if s not in ('', '-0') else '0'


def _write_svg(filepath, loops_bu, mm_per_bu, margin_mm, stroke_width_mm):
    loops_mm = [[(x * mm_per_bu, y * mm_per_bu) for x, y in loop] for loop in loops_bu]
    xs = [x for loop in loops_mm for x, _ in loop]
    ys = [y for loop in loops_mm for _, y in loop]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)

    width = (maxx - minx) + 2 * margin_mm
    height = (maxy - miny) + 2 * margin_mm
    if width <= 0 or height <= 0 or not all(math.isfinite(v) for v in (width, height)):
        raise ValueError("Computed SVG dimensions are invalid.")

    # Shift to positive coordinates and flip Y for conventional SVG screen coordinates.
    transformed = []
    for loop in loops_mm:
        pts = []
        for x, y in loop:
            sx = x - minx + margin_mm
            sy = maxy - y + margin_mm
            pts.append((sx, sy))
        transformed.append(pts)

    paths = []
    for pts in transformed:
        d = [f"M {_fmt(pts[0][0])},{_fmt(pts[0][1])}"]
        for x, y in pts[1:]:
            d.append(f"L {_fmt(x)},{_fmt(y)}")
        d.append("Z")
        paths.append(" ".join(d))

    with open(filepath, 'w', encoding='utf-8', newline='\n') as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        f.write(
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{_fmt(width)}mm" height="{_fmt(height)}mm" '
            f'viewBox="0 0 {_fmt(width)} {_fmt(height)}">\n'
        )
        f.write('  <g fill="none" stroke="#000000" '
                f'stroke-width="{_fmt(stroke_width_mm)}" vector-effect="non-scaling-stroke">\n')
        for d in paths:
            f.write(f'    <path d="{html.escape(d, quote=True)}"/>\n')
        f.write('  </g>\n')
        f.write('</svg>\n')

    return width, height, (maxx - minx), (maxy - miny)


class EXPORT_OT_laser_svg_global_plate(bpy.types.Operator, ExportHelper):
    bl_idname = "export_mesh.laser_svg_global_plate"
    bl_label = "Export Laser SVG"
    bl_options = {'REGISTER'}

    filename_ext = ".svg"
    filter_glob: StringProperty(default="*.svg", options={'HIDDEN'})

    projection_plane: EnumProperty(
        name="Global plane",
        description="Projection plane. Auto uses the smallest global bounding-box extent as plate thickness",
        items=[
            ('AUTO', "Auto", "Detect XY/XZ/YZ from the thinnest global axis"),
            ('XY', "XY", "Plate lies parallel to global XY; thickness is along Z"),
            ('XZ', "XZ", "Plate lies parallel to global XZ; thickness is along Y"),
            ('YZ', "YZ", "Plate lies parallel to global YZ; thickness is along X"),
        ],
        default='AUTO',
    )

    unit_mode: EnumProperty(
        name="Units",
        description="How Blender coordinates are converted to millimetres in the SVG",
        items=[
            ('SCENE', "Use scene units", "Use Scene > Units > Unit Scale (1 BU = Unit Scale metres)"),
            ('BU_MM', "1 BU = 1 mm", "Treat one Blender unit as exactly one millimetre"),
        ],
        default='SCENE',
    )

    apply_modifiers: BoolProperty(
        name="Use evaluated mesh",
        description="Export the geometry after modifiers. Disable bevel/chamfer modifiers if you want the pre-bevel laser profile",
        default=True,
    )

    normal_threshold: FloatProperty(
        name="Cap parallelism",
        description="Minimum absolute normal component used to identify faces parallel to the chosen global plane",
        default=0.9999,
        min=0.5,
        max=1.0,
        precision=4,
    )

    cap_tolerance_rel: FloatProperty(
        name="Cap tolerance",
        description="Relative tolerance (fraction of thickness) for grouping coplanar faces on the outer cap",
        default=1e-5,
        min=1e-8,
        max=1e-2,
        precision=7,
    )

    margin_mm: FloatProperty(
        name="SVG margin (mm)",
        default=0.0,
        min=0.0,
        soft_max=20.0,
        precision=3,
    )

    stroke_width_mm: FloatProperty(
        name="Stroke width (mm)",
        description="Visual stroke only; path centreline is the cut geometry",
        default=0.1,
        min=0.001,
        soft_max=1.0,
        precision=3,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "projection_plane")
        layout.label(text="Exports visible face: XY=Top, XZ=Front, YZ=Right")
        layout.prop(self, "unit_mode")
        if self.unit_mode == 'SCENE':
            u = context.scene.unit_settings
            mm_per_bu = u.scale_length * 1000.0
            layout.label(text=f"Current conversion: 1 BU = {mm_per_bu:g} mm")
            if u.system == 'NONE':
                layout.label(text="Scene Unit System is None: verify Unit Scale carefully.", icon='ERROR')
        layout.prop(self, "apply_modifiers")
        layout.prop(self, "normal_threshold")
        layout.prop(self, "cap_tolerance_rel")
        layout.prop(self, "margin_mm")
        layout.prop(self, "stroke_width_mm")

    def execute(self, context):
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "Select at least one mesh object.")
            return {'CANCELLED'}

        if self.unit_mode == 'SCENE':
            mm_per_bu = context.scene.unit_settings.scale_length * 1000.0
        else:
            mm_per_bu = 1.0

        if not math.isfinite(mm_per_bu) or mm_per_bu <= 0:
            self.report({'ERROR'}, "Invalid unit conversion. Check Scene > Units > Unit Scale.")
            return {'CANCELLED'}

        depsgraph = context.evaluated_depsgraph_get()
        all_loops = []
        detected_axes = []

        try:
            for obj in objs:
                loops, thin_axis, ext = _cap_boundary_loops(
                    obj,
                    depsgraph,
                    self.projection_plane,
                    self.normal_threshold,
                    self.cap_tolerance_rel,
                    self.apply_modifiers,
                )
                all_loops.extend(loops)
                detected_axes.append(thin_axis)

            # Multiple objects can share one SVG only when projected onto the same global plane.
            if len(set(detected_axes)) > 1:
                planes = ", ".join(sorted({PLANE_FROM_AXIS[a] for a in detected_axes}))
                raise ValueError(
                    f"Selected objects resolve to different global planes ({planes}). "
                    "Export them separately or choose a projection plane explicitly."
                )

            width, height, geom_w, geom_h = _write_svg(
                self.filepath,
                all_loops,
                mm_per_bu,
                self.margin_mm,
                self.stroke_width_mm,
            )

            axis = detected_axes[0]
            plane = PLANE_FROM_AXIS[axis]
            view = VIEW_NAME_FROM_AXIS[axis]
            self.report(
                {'INFO'},
                f"SVG exported from {view} face: geometry {geom_w:.3f} × {geom_h:.3f} mm "
                f"on global {plane}; canvas {width:.3f} × {height:.3f} mm"
            )
            return {'FINISHED'}

        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


def menu_func_export(self, context):
    self.layout.operator(EXPORT_OT_laser_svg_global_plate.bl_idname, text="Laser SVG (.svg)")


classes = (EXPORT_OT_laser_svg_global_plate,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
